/* =========================================================
   BIG SAVE — V1 APPLICATION
   Vanilla JavaScript + Supabase
========================================================= */


/* =========================================================
   SUPABASE CONFIGURATION
========================================================= */

const SUPABASE_URL =
    "https://cnyytzqppptcrhxuruch.supabase.co";

const SUPABASE_ANON_KEY =
    "sb_publishable_XmZUHvoOQ4IIMufsD0XR6g_Kdq8So0w";

const supabaseClient =
    window.supabase.createClient(
        SUPABASE_URL,
        SUPABASE_ANON_KEY
    );


/* =========================================================
   GLOBAL STATE
========================================================= */

let currentUser = null;
let currentProfile = null;
let currentPage = "home";

let currentProduct = null;
let currentPublicProfile = null;

let discoverSearchTimer = null;
let memberSearchTimer = null;

let confirmCallback = null;

let currentSubscription = {
    plan: "free",
    status: "active",
    expires_at: null,
    daily_limit: 0
};

const categories = [
    "Mobiles & Tablets",
    "Computers & Laptops",
    "Audio & Headphones",
    "TV & Home Entertainment",
    "Gaming",
    "Cameras & Photography",
    "Home & Kitchen",
    "Furniture",
    "Fashion & Clothing",
    "Footwear",
    "Beauty & Personal Care",
    "Toys & Kids",
    "Books & Education",
    "Sports & Fitness",
    "Tools & Hardware",
    "Automotive",
    "Pet Supplies",
    "Bags & Accessories",
    "Jewellery & Watches",
    "Grocery & Daily Essentials",
    "Arts, Crafts & Hobbies",
    "Office Supplies",
    "Software & Digital Products",
    "Others"
];

const plans = {
    free: {
        name: "Free",
        price: "₹0",
        period: "",
        dailyLimit: 0
    },

    basic_monthly: {
        name: "Basic Monthly",
        price: "₹999",
        period: "/month",
        dailyLimit: 5
    },

    basic_yearly: {
        name: "Basic Yearly",
        price: "₹3600",
        period: "/year",
        dailyLimit: 10
    },

    pro_yearly: {
        name: "Pro Yearly",
        price: "₹4999",
        period: "/year",
        dailyLimit: 20
    }
};


/* =========================================================
   INITIALIZATION
========================================================= */

document.addEventListener("DOMContentLoaded", async () => {

    applySavedTheme();

    populateCategorySelectors();

    setupImagePreview();

    await initializeApp();

});


async function initializeApp() {

    try {

        const {
            data,
            error
        } = await supabaseClient.auth.getSession();

        if (error) {
            console.error(error);
            showAuthScreen();
            return;
        }

        if (data.session) {

            currentUser = data.session.user;

            await loadUserApplication();

        } else {

            showAuthScreen();

        }

    } catch (error) {

        console.error(error);

        showAuthScreen();

    }


    supabaseClient.auth.onAuthStateChange(
        async (event, session) => {

            if (session?.user) {

                currentUser = session.user;

                if (
                    event === "SIGNED_IN" ||
                    event === "INITIAL_SESSION"
                ) {
                    await loadUserApplication();
                }

            } else {

                currentUser = null;
                currentProfile = null;

                showAuthScreen();

            }

        }
    );

}


/* =========================================================
   AUTH UI
========================================================= */

function showAuthScreen() {

    document
        .getElementById("authScreen")
        ?.classList.remove("hidden");

    document
        .getElementById("mainApp")
        ?.classList.add("hidden");

}


function showMainApp() {

    document
        .getElementById("authScreen")
        ?.classList.add("hidden");

    document
        .getElementById("mainApp")
        ?.classList.remove("hidden");

}


/* =========================================================
   LOGIN / SIGNUP SWITCHING
========================================================= */

function showLogin() {

    document
        .getElementById("loginForm")
        ?.classList.remove("hidden");

    document
        .getElementById("signupForm")
        ?.classList.add("hidden");

    document
        .getElementById("forgotPasswordForm")
        ?.classList.add("hidden");

}


function showSignup() {

    document
        .getElementById("loginForm")
        ?.classList.add("hidden");

    document
        .getElementById("signupForm")
        ?.classList.remove("hidden");

    document
        .getElementById("forgotPasswordForm")
        ?.classList.add("hidden");

}


function showForgotPassword() {

    document
        .getElementById("loginForm")
        ?.classList.add("hidden");

    document
        .getElementById("signupForm")
        ?.classList.add("hidden");

    document
        .getElementById("forgotPasswordForm")
        ?.classList.remove("hidden");

}


/* =========================================================
   LOGIN
========================================================= */

async function login() {

    const email =
        document.getElementById("loginEmail").value.trim();

    const password =
        document.getElementById("loginPassword").value;

    setMessage(
        "loginMessage",
        "Logging in..."
    );

    try {

        const {
            data,
            error
        } = await supabaseClient.auth.signInWithPassword({
            email,
            password
        });

        if (error) {
            throw error;
        }

        currentUser = data.user;

        await loadUserApplication();

        showToast(
            "Welcome back!",
            "success"
        );

    } catch (error) {

        console.error(error);

        setMessage(
            "loginMessage",
            friendlyAuthError(error),
            true
        );

    }

}


/* =========================================================
   SIGNUP
========================================================= */

async function signup() {

    const fullName =
        document.getElementById("signupName").value.trim();

    const email =
        document.getElementById("signupEmail").value.trim();

    const password =
        document.getElementById("signupPassword").value;

    const dateOfBirth =
        document.getElementById("signupDob").value;

    const logoFile =
        document.getElementById("signupLogo").files[0];

    if (!fullName || !email || !password || !dateOfBirth) {

        setMessage(
            "signupMessage",
            "Please complete all required fields.",
            true
        );

        return;
    }

    setMessage(
        "signupMessage",
        "Creating your account..."
    );

    try {

        const {
            data,
            error
        } = await supabaseClient.auth.signUp({

            email,
            password,

            options: {
                data: {
                    full_name: fullName,
                    date_of_birth: dateOfBirth
                }
            }

        });

        if (error) {
            throw error;
        }

        if (!data.user) {
            throw new Error("Account creation failed.");
        }

        currentUser = data.user;

        /*
         * The V1 specification expects email confirmation
         * to be disabled in Supabase.
         */

        if (logoFile) {

            const uploadedUrl =
                await uploadProfileImage(
                    data.user.id,
                    logoFile
                );

            if (uploadedUrl) {

                await supabaseClient
                    .from("profiles")
                    .update({
                        logo_url: uploadedUrl
                    })
                    .eq("id", data.user.id);

            }

        }

        await ensureProfileExists();

        await loadUserApplication();

        showToast(
            "Account created successfully!",
            "success"
        );

    } catch (error) {

        console.error(error);

        setMessage(
            "signupMessage",
            friendlyAuthError(error),
            true
        );

    }

}


/* =========================================================
   PASSWORD RESET
========================================================= */

async function sendPasswordReset() {

    const email =
        document.getElementById("forgotEmail").value.trim();

    if (!email) {

        setMessage(
            "forgotMessage",
            "Enter your email address.",
            true
        );

        return;
    }

    try {

        const {
            error
        } = await supabaseClient.auth.resetPasswordForEmail(
            email,
            {
                redirectTo:
                    `${window.location.origin}${window.location.pathname}`
            }
        );

        if (error) {
            throw error;
        }

        setMessage(
            "forgotMessage",
            "Password reset link sent."
        );

    } catch (error) {

        console.error(error);

        setMessage(
            "forgotMessage",
            friendlyAuthError(error),
            true
        );

    }

}


/* =========================================================
   LOGOUT
========================================================= */

async function logout() {

    try {

        const {
            error
        } = await supabaseClient.auth.signOut();

        if (error) {
            throw error;
        }

        currentUser = null;
        currentProfile = null;

        showAuthScreen();

        showLogin();

    } catch (error) {

        console.error(error);

        showToast(
            "Unable to log out.",
            "error"
        );

    }

}


/* =========================================================
   USER APPLICATION LOAD
========================================================= */

async function loadUserApplication() {

    if (!currentUser) {
        showAuthScreen();
        return;
    }

    showMainApp();

    await ensureProfileExists();

    await loadCurrentProfile();

    await loadSubscription();

    await updateHeader();

    await updateCommunityCount();

    await loadLatestProducts();

    await loadNotificationBadge();

    await updateProfilePage();

    await updateAddProductPage();

    showPage("home");

}


/* =========================================================
   PROFILE
========================================================= */

async function ensureProfileExists() {

    if (!currentUser) return;

    const {
        data,
        error
    } = await supabaseClient
        .from("profiles")
        .select("id")
        .eq("id", currentUser.id)
        .maybeSingle();

    if (error) {

        console.error(
            "Profile check error:",
            error
        );

        return;

    }

    if (!data) {

        const metadata =
            currentUser.user_metadata || {};

        const {
            error: insertError
        } = await supabaseClient
            .from("profiles")
            .insert({
                id: currentUser.id,
                full_name:
                    metadata.full_name ||
                    "Big Save Member",
                date_of_birth:
                    metadata.date_of_birth || null
            });

        if (
            insertError &&
            insertError.code !== "23505"
        ) {
            console.error(
                "Profile creation error:",
                insertError
            );
        }

    }

}


async function loadCurrentProfile() {

    if (!currentUser) return;

    const {
        data,
        error
    } = await supabaseClient
        .from("profiles")
        .select(`
            id,
            full_name,
            date_of_birth,
            logo_url,
            created_at,
            updated_at
        `)
        .eq("id", currentUser.id)
        .single();

    if (error) {

        console.error(
            "Profile loading error:",
            error
        );

        return;

    }

    currentProfile = data;

}


/* =========================================================
   PROFILE IMAGE UPLOAD
========================================================= */

async function uploadProfileImage(
    userId,
    file
) {

    if (!file) return null;

    const extension =
        getFileExtension(file.name);

    const filePath =
        `profiles/${userId}/profile-${Date.now()}.${extension}`;

    const {
        error
    } = await supabaseClient.storage
        .from("profile-images")
        .upload(
            filePath,
            file,
            {
                upsert: true,
                contentType: file.type
            }
        );

    if (error) {

        /*
         * If the profile bucket isn't available yet,
         * SQL setup will create it.
         */

        console.error(
            "Profile image upload error:",
            error
        );

        throw new Error(
            "Profile photo upload failed."
        );

    }

    const {
        data
    } = supabaseClient.storage
        .from("profile-images")
        .getPublicUrl(filePath);

    return data.publicUrl;

}


/* =========================================================
   PRODUCT IMAGE UPLOAD
========================================================= */

async function uploadProductImage(
    userId,
    file
) {

    if (!file) return null;

    const extension =
        getFileExtension(file.name);

    const filePath =
        `${userId}/product-${Date.now()}.${extension}`;

    const {
        error
    } = await supabaseClient.storage
        .from("product-images")
        .upload(
            filePath,
            file,
            {
                upsert: false,
                contentType: file.type
            }
        );

    if (error) {

        console.error(
            "Product image upload error:",
            error
        );

        throw new Error(
            "Product image upload failed."
        );

    }

    const {
        data
    } = supabaseClient.storage
        .from("product-images")
        .getPublicUrl(filePath);

    return data.publicUrl;

}


function getFileExtension(filename) {

    const parts =
        filename.split(".");

    return (
        parts.length > 1
            ? parts.pop()
            : "jpg"
    ).toLowerCase();

}


/* =========================================================
   HEADER
========================================================= */

async function updateHeader() {

    if (!currentProfile) return;

    const name =
        currentProfile.full_name ||
        "Member";

    const image =
        currentProfile.logo_url ||
        "big-save-logo.png";

    const nameElement =
        document.getElementById("headerUserName");

    const imageElement =
        document.getElementById("headerProfileImage");

    if (nameElement) {
        nameElement.textContent = name;
    }

    if (imageElement) {
        imageElement.src = image;
    }

}


/* =========================================================
   NAVIGATION
========================================================= */

async function showPage(page) {

    if (!currentUser) {
        showAuthScreen();
        return;
    }

    const pages = [
        "home",
        "discover",
        "productDetail",
        "following",
        "members",
        "publicProfile",
        "addProduct",
        "notifications",
        "profile",
        "followers",
        "followingMembers"
    ];

    pages.forEach(name => {

        const element =
            document.getElementById(
                `${name}Page`
            );

        if (element) {
            element.classList.add("hidden");
        }

    });


    const target =
        document.getElementById(
            `${page}Page`
        );

    if (!target) return;

    target.classList.remove("hidden");

    currentPage = page;

    updateNavigation(page);


    if (page === "home") {

        await loadLatestProducts();

        await updateCommunityCount();

    }

    if (page === "discover") {

        await loadDiscoverProducts();

    }

    if (page === "following") {

        await loadFollowingProducts();

    }

    if (page === "members") {

        await searchMembers();

    }

    if (page === "notifications") {

        await loadNotifications();

    }

    if (page === "profile") {

        await updateProfilePage();

    }

    if (page === "followers") {

        await loadFollowers();

    }

    if (page === "followingMembers") {

        await loadFollowingMembers();

    }

    if (page === "addProduct") {

        await updateAddProductPage();

    }

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


function updateNavigation(page) {

    document
        .querySelectorAll(".nav-btn")
        .forEach(button => {

            button.classList.remove("active");

            if (
                button.dataset.page === page
            ) {
                button.classList.add("active");
            }

        });

}


/* =========================================================
   GLOBAL SEARCH
========================================================= */

function handleGlobalSearch(event) {

    if (event.key === "Enter") {
        performGlobalSearch();
    }

}


function performGlobalSearch() {

    const value =
        document
            .getElementById("globalSearch")
            .value
            .trim();

    if (!value) {
        showPage("members");
        return;
    }

    document
        .getElementById("memberSearch")
        .value = value;

    showPage("members");

}


/* =========================================================
   COMMUNITY COUNT
========================================================= */

async function updateCommunityCount() {

    const {
        count,
        error
    } = await supabaseClient
        .from("profiles")
        .select("id", {
            count: "exact",
            head: true
        });

    if (error) {

        console.error(
            "Community count error:",
            error
        );

        return;

    }

    const formatted =
        Number(count || 0).toLocaleString("en-IN");

    const element =
        document.getElementById(
            "communityMemberCount"
        );

    if (element) {
        element.textContent = formatted;
    }

}


/* =========================================================
   CATEGORY SELECTORS
========================================================= */

function populateCategorySelectors() {

    const selectors = [
        "productCategory",
        "editProductCategory"
    ];

    selectors.forEach(id => {

        const select =
            document.getElementById(id);

        if (!select) return;

        const current =
            select.value;

        if (id === "productCategory") {

            select.innerHTML = `
                <option value="">
                    Select category
                </option>
            `;

        } else {

            select.innerHTML = "";

        }

        categories.forEach(category => {

            const option =
                document.createElement("option");

            option.value = category;
            option.textContent = category;

            select.appendChild(option);

        });

        select.value = current;

    });

}


/* =========================================================
   PRODUCT QUERIES
========================================================= */

async function fetchProducts({
    search = "",
    category = "",
    uploader = "",
    sort = "newest",
    ownerId = null,
    limit = 40
} = {}) {

    let query =
        supabaseClient
            .from("products")
            .select(`
                id,
                owner_id,
                product_name,
                affiliate_url,
                image_url,
                description,
                category,
                created_at,
                profiles:owner_id (
                    id,
                    full_name,
                    logo_url
                )
            `)
            .limit(limit);


    if (search) {

        query =
            query.ilike(
                "product_name",
                `%${search}%`
            );

    }


    if (category) {

        query =
            query.eq(
                "category",
                category
            );

    }


    if (ownerId) {

        query =
            query.eq(
                "owner_id",
                ownerId
            );

    }


    if (sort === "oldest") {

        query =
            query.order(
                "created_at",
                {
                    ascending: true
                }
            );

    } else {

        query =
            query.order(
                "created_at",
                {
                    ascending: false
                }
            );

    }


    const {
        data,
        error
    } = await query;


    if (error) {
        throw error;
    }


    let products =
        await enrichProducts(data || []);


    if (uploader) {

        const text =
            uploader.toLowerCase();

        products =
            products.filter(product =>
                (
                    product.profiles?.full_name ||
                    ""
                )
                    .toLowerCase()
                    .includes(text)
            );

    }


    if (sort === "popular") {

        products.sort(
            (a, b) =>
                b.likeCount -
                a.likeCount
        );

    }


    if (sort === "viewed") {

        products.sort(
            (a, b) =>
                b.viewCount -
                a.viewCount
        );

    }


    return products;

}


/* =========================================================
   ENRICH PRODUCTS
========================================================= */

async function enrichProducts(products) {

    if (!products.length) {
        return [];
    }

    const ids =
        products.map(
            product => product.id
        );


    const {
        data: likes,
        error: likesError
    } = await supabaseClient
        .from("product_likes")
        .select(
            "product_id,user_id"
        )
        .in(
            "product_id",
            ids
        );


    if (likesError) {
        console.error(likesError);
    }


    const {
        data: clicks,
        error: clicksError
    } = await supabaseClient
        .from("click_events")
        .select(
            "product_id"
        )
        .in(
            "product_id",
            ids
        );


    if (clicksError) {
        console.error(clicksError);
    }


    return products.map(product => {

        const productLikes =
            (likes || []).filter(
                like =>
                    like.product_id ===
                    product.id
            );

        const productClicks =
            (clicks || []).filter(
                click =>
                    click.product_id ===
                    product.id
            );

        const likedByUser =
            currentUser
                ? productLikes.some(
                    like =>
                        like.user_id ===
                        currentUser.id
                )
                : false;

        return {
            ...product,
            likeCount:
                productLikes.length,
            viewCount:
                productClicks.length,
            likedByUser
        };

    });

}


/* =========================================================
   LATEST PRODUCTS
========================================================= */

async function loadLatestProducts() {

    const container =
        document.getElementById(
            "latestProducts"
        );

    if (!container) return;

    container.innerHTML =
        `<div class="loading-card">
            Loading products...
        </div>`;


    try {

        const products =
            await fetchProducts({
                sort: "newest",
                limit: 12
            });

        renderProducts(
            products,
            container
        );

    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load products right now.
            </div>`;

    }

}


/* =========================================================
   DISCOVER
========================================================= */

async function loadDiscoverProducts() {

    const container =
        document.getElementById(
            "discoverProducts"
        );

    if (!container) return;

    container.innerHTML =
        `<div class="loading-card">
            Loading products...
        </div>`;


    const search =
        document
            .getElementById("discoverSearch")
            ?.value
            .trim() || "";


    const category =
        document
            .getElementById("categoryFilter")
            ?.value || "";


    const uploader =
        document
            .getElementById("uploaderFilter")
            ?.value
            .trim() || "";


    const sort =
        document
            .getElementById("sortProducts")
            ?.value || "newest";


    try {

        const products =
            await fetchProducts({
                search,
                category,
                uploader,
                sort
            });

        renderProducts(
            products,
            container
        );

    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load products.
            </div>`;

    }

}


function debouncedDiscoverSearch() {

    clearTimeout(
        discoverSearchTimer
    );

    discoverSearchTimer =
        setTimeout(
            () => loadDiscoverProducts(),
            350
        );

}


/* =========================================================
   RENDER PRODUCTS
========================================================= */

function renderProducts(
    products,
    container
) {

    if (!products.length) {

        container.innerHTML =
            `<div class="loading-card">
                No products available yet.
            </div>`;

        return;

    }


    container.innerHTML = "";


    products.forEach(product => {

        const card =
            createProductCard(product);

        container.appendChild(card);

    });

}


function createProductCard(product) {

    const template =
        document.getElementById(
            "productCardTemplate"
        );

    const card =
        template.content
            .cloneNode(true);

    const article =
        card.querySelector(
            ".product-card"
        );


    const image =
        card.querySelector(
            ".product-image"
        );

    image.src =
        product.image_url ||
        "big-save-logo.png";

    image.alt =
        product.product_name;


    card.querySelector(
        ".product-category"
    ).textContent =
        product.category;


    card.querySelector(
        ".product-title"
    ).textContent =
        product.product_name;


    card.querySelector(
        ".product-description"
    ).textContent =
        product.description ||
        "No description provided.";


    const uploaderAvatar =
        card.querySelector(
            ".uploader-avatar"
        );

    uploaderAvatar.src =
        product.profiles?.logo_url ||
        "big-save-logo.png";


    const uploaderName =
        card.querySelector(
            ".uploader-name"
        );

    uploaderName.textContent =
        product.profiles?.full_name ||
        "Big Save Member";


    const stats =
        card.querySelector(
            ".product-stats"
        );

    stats.querySelector(
        ".product-likes"
    ).textContent =
        `♡ ${product.likeCount}`;


    stats.querySelector(
        ".product-views"
    ).textContent =
        `👁 ${product.viewCount}`;


    const likeButton =
        card.querySelector(
            ".like-btn"
        );

    if (product.likedByUser) {

        likeButton.classList.add(
            "liked"
        );

        likeButton.textContent =
            "♥ Unlike";

    }


    likeButton.addEventListener(
        "click",
        async event => {

            event.stopPropagation();

            await toggleLike(
                product,
                likeButton,
                stats
            );

        }
    );


    card.querySelector(
        ".view-deal-btn"
    ).addEventListener(
        "click",
        event => {

            event.stopPropagation();

            openProductDeal(
                product
            );

        }
    );


    card.querySelector(
        ".uploader-row"
    ).addEventListener(
        "click",
        event => {

            event.stopPropagation();

            openPublicProfile(
                product.owner_id
            );

        }
    );


    article.addEventListener(
        "click",
        event => {

            if (
                event.target.closest(
                    "button"
                )
            ) {
                return;
            }

            openProductDetail(
                product.id
            );

        }
    );


    return card;

}


/* =========================================================
   PRODUCT DETAIL
========================================================= */

async function openProductDetail(
    productId
) {

    const {
        data,
        error
    } = await supabaseClient
        .from("products")
        .select(`
            id,
            owner_id,
            product_name,
            affiliate_url,
            image_url,
            description,
            category,
            created_at,
            profiles:owner_id (
                id,
                full_name,
                logo_url,
                created_at
            )
        `)
        .eq(
            "id",
            productId
        )
        .single();


    if (error) {

        console.error(error);

        showToast(
            "Product could not be loaded.",
            "error"
        );

        return;

    }


    const [
        enriched
    ] =
        await enrichProducts([data]);


    currentProduct =
        enriched;


    const container =
        document.getElementById(
            "productDetail"
        );


    container.innerHTML = "";


    const wrapper =
        document.createElement("div");

    wrapper.className =
        "product-detail-grid";


    const left =
        document.createElement("div");


    const image =
        document.createElement("img");

    image.className =
        "product-detail-image";

    image.src =
        currentProduct.image_url ||
        "big-save-logo.png";

    image.alt =
        currentProduct.product_name;


    left.appendChild(image);


    const right =
        document.createElement("div");


    right.innerHTML = `
        <span class="eyebrow">
            ${escapeHtml(currentProduct.category)}
        </span>

        <h1>
            ${escapeHtml(currentProduct.product_name)}
        </h1>

        <p class="product-detail-description">
            ${escapeHtml(currentProduct.description || "")}
        </p>

        <button
            type="button"
            class="uploader-row"
            id="detailUploader"
        >
            <img
                class="uploader-avatar"
                src="${escapeAttribute(
                    currentProduct.profiles?.logo_url ||
                    "big-save-logo.png"
                )}"
                alt=""
            >

            <span class="uploader-name">
                ${escapeHtml(
                    currentProduct.profiles?.full_name ||
                    "Big Save Member"
                )}
            </span>
        </button>

        <div class="product-detail-meta">
            <span>
                📅 ${formatDate(currentProduct.created_at)}
            </span>

            <span>
                👁 ${currentProduct.viewCount}
            </span>

            <span>
                ♡ ${currentProduct.likeCount}
            </span>
        </div>

        <div class="product-detail-actions">

            <button
                type="button"
                class="like-btn ${
                    currentProduct.likedByUser
                        ? "liked"
                        : ""
                }"
                id="detailLikeButton"
            >
                ${
                    currentProduct.likedByUser
                        ? "♥ Unlike"
                        : "♡ Like"
                }
            </button>

            <button
                type="button"
                class="primary-btn"
                id="detailDealButton"
            >
                View Deal
            </button>

        </div>
    `;


    wrapper.appendChild(left);
    wrapper.appendChild(right);

    container.appendChild(wrapper);


    document
        .getElementById(
            "detailUploader"
        )
        .addEventListener(
            "click",
            () =>
                openPublicProfile(
                    currentProduct.owner_id
                )
        );


    document
        .getElementById(
            "detailLikeButton"
        )
        .addEventListener(
            "click",
            async () => {

                await toggleLike(
                    currentProduct,
                    document.getElementById(
                        "detailLikeButton"
                    ),
                    null
                );

                await openProductDetail(
                    productId
                );

            }
        );


    document
        .getElementById(
            "detailDealButton"
        )
        .addEventListener(
            "click",
            () =>
                openProductDeal(
                    currentProduct
                )
        );


    showPageWithoutReload(
        "productDetail"
    );

}


function showPageWithoutReload(
    page
) {

    const pages = [
        "home",
        "discover",
        "productDetail",
        "following",
        "members",
        "publicProfile",
        "addProduct",
        "notifications",
        "profile",
        "followers",
        "followingMembers"
    ];


    pages.forEach(name => {

        document
            .getElementById(
                `${name}Page`
            )
            ?.classList.add("hidden");

    });


    document
        .getElementById(
            `${page}Page`
        )
        ?.classList.remove("hidden");

    currentPage = page;

    updateNavigation(page);

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


/* =========================================================
   VIEW DEAL / CLICK EVENT
========================================================= */

async function openProductDeal(
    product
) {

    if (!product?.affiliate_url) {

        showToast(
            "This product does not have a valid link.",
            "error"
        );

        return;

    }


    /*
     * Open first so popup blockers are less likely
     * to block the user-requested navigation.
     */

    window.open(
        product.affiliate_url,
        "_blank",
        "noopener,noreferrer"
    );


    try {

        const {
            error
        } = await supabaseClient
            .from("click_events")
            .insert({
                product_id: product.id,
                user_id: currentUser.id
            });

        if (error) {
            console.error(
                "Click event error:",
                error
            );
        }

    } catch (error) {

        console.error(error);

    }

}


/* =========================================================
   LIKES
========================================================= */

async function toggleLike(
    product,
    button,
    statsElement
) {

    if (!currentUser) {
        showToast(
            "Please log in first.",
            "error"
        );
        return;
    }


    try {

        if (product.likedByUser) {

            const {
                error
            } = await supabaseClient
                .from("product_likes")
                .delete()
                .eq(
                    "product_id",
                    product.id
                )
                .eq(
                    "user_id",
                    currentUser.id
                );

            if (error) {
                throw error;
            }

            product.likedByUser =
                false;

            product.likeCount =
                Math.max(
                    0,
                    product.likeCount - 1
                );

            if (button) {

                button.classList.remove(
                    "liked"
                );

                button.textContent =
                    "♡ Like";

            }

        } else {

            const {
                error
            } = await supabaseClient
                .from("product_likes")
                .insert({
                    product_id: product.id,
                    user_id: currentUser.id
                });

            if (error) {

                if (error.code === "23505") {

                    product.likedByUser =
                        true;

                } else {

                    throw error;

                }

            } else {

                product.likeCount += 1;

                product.likedByUser =
                    true;

            }

            if (button) {

                button.classList.add(
                    "liked"
                );

                button.textContent =
                    "♥ Unlike";

            }

        }


        if (statsElement) {

            const likes =
                statsElement.querySelector(
                    ".product-likes"
                );

            if (likes) {

                likes.textContent =
                    `♡ ${product.likeCount}`;

            }

        }

    } catch (error) {

        console.error(error);

        showToast(
            "Unable to update like.",
            "error"
        );

    }

}


/* =========================================================
   MEMBER SEARCH
========================================================= */

function debouncedMemberSearch() {

    clearTimeout(
        memberSearchTimer
    );

    memberSearchTimer =
        setTimeout(
            searchMembers,
            350
        );

}


async function searchMembers() {

    const container =
        document.getElementById(
            "memberResults"
        );

    if (!container) return;


    const search =
        document
            .getElementById("memberSearch")
            ?.value
            .trim() || "";


    if (!search) {

        container.innerHTML =
            `<div class="loading-card">
                Search for members.
            </div>`;

        return;

    }


    container.innerHTML =
        `<div class="loading-card">
            Searching members...
        </div>`;


    try {

        const {
            data,
            error
        } = await supabaseClient
            .from("profiles")
            .select(`
                id,
                full_name,
                logo_url,
                created_at
            `)
            .ilike(
                "full_name",
                `%${search}%`
            )
            .limit(30);


        if (error) {
            throw error;
        }


        await renderMemberResults(
            data || [],
            container
        );

    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to search members.
            </div>`;

    }

}


async function renderMemberResults(
    members,
    container
) {

    if (!members.length) {

        container.innerHTML =
            `<div class="loading-card">
                No members found.
            </div>`;

        return;

    }


    container.innerHTML = "";


    for (const member of members) {

        const card =
            await createMemberCard(
                member
            );

        container.appendChild(card);

    }

}


/* =========================================================
   MEMBER CARD
========================================================= */

async function createMemberCard(
    member
) {

    const template =
        document.getElementById(
            "memberCardTemplate"
        );

    const card =
        template.content
            .cloneNode(true);


    card.querySelector(
        ".member-avatar"
    ).src =
        member.logo_url ||
        "big-save-logo.png";


    card.querySelector(
        ".member-name"
    ).textContent =
        member.full_name ||
        "Big Save Member";


    const {
        count: productCount
    } = await supabaseClient
        .from("products")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "owner_id",
            member.id
        );


    const {
        count: followerCount
    } = await supabaseClient
        .from("follows")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "following_id",
            member.id
        );


    const {
        count: followingCount
    } = await supabaseClient
        .from("follows")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "follower_id",
            member.id
        );


    card.querySelector(
        ".member-product-count"
    ).textContent =
        `${productCount || 0} products`;


    card.querySelector(
        ".member-followers"
    ).textContent =
        `${followerCount || 0} followers`;


    card.querySelector(
        ".member-following"
    ).textContent =
        `${followingCount || 0} following`;


    const profileButton =
        card.querySelector(
            ".profile-btn"
        );


    profileButton.addEventListener(
        "click",
        () =>
            openPublicProfile(
                member.id
            )
    );


    const followButton =
        card.querySelector(
            ".follow-btn"
        );


    if (
        currentUser &&
        member.id === currentUser.id
    ) {

        followButton.classList.add(
            "hidden"
        );

    } else {

        const following =
            await isFollowing(
                member.id
            );

        followButton.textContent =
            following
                ? "Following"
                : "Follow";

        if (following) {

            followButton.classList.add(
                "secondary-btn"
            );

            followButton.classList.remove(
                "primary-btn"
            );

        }


        followButton.addEventListener(
            "click",
            async () => {

                const nowFollowing =
                    await toggleFollow(
                        member.id
                    );

                followButton.textContent =
                    nowFollowing
                        ? "Following"
                        : "Follow";

            }
        );

    }


    return card;

}


/* =========================================================
   FOLLOW SYSTEM
========================================================= */

async function isFollowing(
    memberId
) {

    if (!currentUser) {
        return false;
    }

    const {
        data,
        error
    } = await supabaseClient
        .from("follows")
        .select("id")
        .eq(
            "follower_id",
            currentUser.id
        )
        .eq(
            "following_id",
            memberId
        )
        .maybeSingle();


    if (error) {

        console.error(error);

        return false;

    }


    return !!data;

}


async function toggleFollow(
    memberId
) {

    if (!currentUser) {

        showToast(
            "Please log in first.",
            "error"
        );

        return false;

    }


    if (
        currentUser.id === memberId
    ) {

        showToast(
            "You cannot follow yourself.",
            "error"
        );

        return false;

    }


    const following =
        await isFollowing(
            memberId
        );


    try {

        if (following) {

            const {
                error
            } = await supabaseClient
                .from("follows")
                .delete()
                .eq(
                    "follower_id",
                    currentUser.id
                )
                .eq(
                    "following_id",
                    memberId
                );

            if (error) {
                throw error;
            }

            showToast(
                "Unfollowed member.",
                "success"
            );

            return false;

        }


        const {
            error
        } = await supabaseClient
            .from("follows")
            .insert({
                follower_id:
                    currentUser.id,
                following_id:
                    memberId
            });


        if (error) {

            if (error.code === "23505") {
                return true;
            }

            throw error;

        }


        showToast(
            "Member followed.",
            "success"
        );

        return true;

    } catch (error) {

        console.error(error);

        showToast(
            "Unable to update follow status.",
            "error"
        );

        return following;

    }

}


/* =========================================================
   PUBLIC PROFILE
========================================================= */

async function openPublicProfile(
    memberId
) {

    if (!memberId) return;


    const {
        data,
        error
    } = await supabaseClient
        .from("profiles")
        .select(`
            id,
            full_name,
            logo_url,
            created_at
        `)
        .eq(
            "id",
            memberId
        )
        .single();


    if (error) {

        console.error(error);

        showToast(
            "Unable to open profile.",
            "error"
        );

        return;

    }


    currentPublicProfile =
        data;


    await renderPublicProfile(
        data
    );

    await loadPublicProfileProducts(
        memberId
    );


    showPageWithoutReload(
        "publicProfile"
    );

}


async function renderPublicProfile(
    member
) {

    const container =
        document.getElementById(
            "publicProfile"
        );


    const {
        count: followers
    } = await supabaseClient
        .from("follows")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "following_id",
            member.id
        );


    const {
        count: following
    } = await supabaseClient
        .from("follows")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "follower_id",
            member.id
        );


    const {
        count: products
    } = await supabaseClient
        .from("products")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "owner_id",
            member.id
        );


    const followingState =
        await isFollowing(
            member.id
        );


    const notifying =
        await isNotifying(
            member.id
        );


    const isOwnProfile =
        currentUser &&
        currentUser.id === member.id;


    container.innerHTML = `

        <div class="profile-cover"></div>

        <div class="profile-main">

            <div class="profile-avatar-large">

                <img
                    src="${escapeAttribute(
                        member.logo_url ||
                        "big-save-logo.png"
                    )}"
                    alt="Profile"
                >

            </div>

            <div class="profile-information">

                <h1>
                    ${escapeHtml(
                        member.full_name ||
                        "Big Save Member"
                    )}
                </h1>

                <p class="muted">
                    Joined ${formatDate(member.created_at)}
                </p>

            </div>

            ${
                !isOwnProfile
                    ? `
                        <div
                            class="profile-actions"
                            style="
                                display:flex;
                                gap:8px;
                                flex-wrap:wrap;
                            "
                        >

                            <button
                                type="button"
                                id="publicFollowButton"
                                class="${
                                    followingState
                                        ? "secondary-btn"
                                        : "primary-btn"
                                }"
                            >
                                ${
                                    followingState
                                        ? "Following"
                                        : "Follow"
                                }
                            </button>

                            <button
                                type="button"
                                id="publicNotifyButton"
                                class="${
                                    notifying
                                        ? "secondary-btn"
                                        : "primary-btn"
                                }"
                            >
                                ${
                                    notifying
                                        ? "Notifying"
                                        : "Notify"
                                }
                            </button>

                        </div>
                    `
                    : `
                        <button
                            type="button"
                            class="secondary-btn"
                            onclick="showPage('settings')"
                        >
                            Edit Profile
                        </button>
                    `
            }

        </div>

        <div class="profile-stats">

            <button type="button">
                <strong>
                    ${followers || 0}
                </strong>
                <span>Followers</span>
            </button>

            <button type="button">
                <strong>
                    ${following || 0}
                </strong>
                <span>Following</span>
            </button>

            <button type="button">
                <strong>
                    ${products || 0}
                </strong>
                <span>Products</span>
            </button>

        </div>
    `;


    if (!isOwnProfile) {

        document
            .getElementById(
                "publicFollowButton"
            )
            .addEventListener(
                "click",
                async () => {

                    const result =
                        await toggleFollow(
                            member.id
                        );

                    const button =
                        document.getElementById(
                            "publicFollowButton"
                        );

                    button.textContent =
                        result
                            ? "Following"
                            : "Follow";

                    button.className =
                        result
                            ? "secondary-btn"
                            : "primary-btn";

                }
            );


        document
            .getElementById(
                "publicNotifyButton"
            )
            .addEventListener(
                "click",
                async () => {

                    const result =
                        await toggleNotify(
                            member.id
                        );

                    const button =
                        document.getElementById(
                            "publicNotifyButton"
                        );

                    button.textContent =
                        result
                            ? "Notifying"
                            : "Notify";

                    button.className =
                        result
                            ? "secondary-btn"
                            : "primary-btn";

                }
            );

    }

}


async function loadPublicProfileProducts(
    memberId
) {

    const container =
        document.getElementById(
            "publicProfileProducts"
        );


    container.innerHTML =
        `<div class="loading-card">
            Loading products...
        </div>`;


    try {

        const products =
            await fetchProducts({
                ownerId: memberId,
                sort: "newest",
                limit: 100
            });


        /*
         * The V1 public profile has
         * All / New / Popular / Old /
         * category behavior.
         *
         * The current page structure uses the
         * product area directly; this rendering
         * still separates the required groups
         * through the helper below.
         */

        renderProducts(
            products,
            container
        );

    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load member products.
            </div>`;

    }

}


/* =========================================================
   NOTIFY SYSTEM
========================================================= */

async function isNotifying(
    memberId
) {

    if (!currentUser) return false;


    const {
        data,
        error
    } = await supabaseClient
        .from("member_notifications")
        .select("id")
        .eq(
            "subscriber_id",
            currentUser.id
        )
        .eq(
            "member_id",
            memberId
        )
        .maybeSingle();


    if (error) {

        console.error(error);

        return false;

    }


    return !!data;

}


async function toggleNotify(
    memberId
) {

    if (!currentUser) {

        showToast(
            "Please log in first.",
            "error"
        );

        return false;

    }


    if (
        currentUser.id === memberId
    ) {

        showToast(
            "You cannot notify yourself.",
            "error"
        );

        return false;

    }


    const notifying =
        await isNotifying(
            memberId
        );


    try {

        if (notifying) {

            const {
                error
            } = await supabaseClient
                .from("member_notifications")
                .delete()
                .eq(
                    "subscriber_id",
                    currentUser.id
                )
                .eq(
                    "member_id",
                    memberId
                );

            if (error) {
                throw error;
            }

            showToast(
                "Notifications turned off.",
                "success"
            );

            return false;

        }


        const {
            error
        } = await supabaseClient
            .from("member_notifications")
            .insert({
                subscriber_id:
                    currentUser.id,
                member_id:
                    memberId
            });


        if (error) {

            if (error.code === "23505") {
                return true;
            }

            throw error;

        }


        showToast(
            "You will be notified about new products.",
            "success"
        );

        return true;

    } catch (error) {

        console.error(error);

        showToast(
            "Unable to update notification preference.",
            "error"
        );

        return notifying;

    }

}


/* =========================================================
   FOLLOWING FEED
========================================================= */

async function loadFollowingProducts() {

    const container =
        document.getElementById(
            "followingProducts"
        );

    const empty =
        document.getElementById(
            "followingEmpty"
        );


    if (!container) return;


    container.innerHTML =
        `<div class="loading-card">
            Loading your following feed...
        </div>`;


    try {

        const {
            data: follows,
            error
        } = await supabaseClient
            .from("follows")
            .select(
                "following_id"
            )
            .eq(
                "follower_id",
                currentUser.id
            );


        if (error) {
            throw error;
        }


        const ids =
            (follows || []).map(
                row => row.following_id
            );


        if (!ids.length) {

            container.innerHTML = "";

            empty?.classList.remove(
                "hidden"
            );

            return;

        }


        empty?.classList.add(
            "hidden"
        );


        const {
            data: products,
            error: productError
        } = await supabaseClient
            .from("products")
            .select(`
                id,
                owner_id,
                product_name,
                affiliate_url,
                image_url,
                description,
                category,
                created_at,
                profiles:owner_id (
                    id,
                    full_name,
                    logo_url
                )
            `)
            .in(
                "owner_id",
                ids
            )
            .order(
                "created_at",
                {
                    ascending: false
                }
            )
            .limit(50);


        if (productError) {
            throw productError;
        }


        const enriched =
            await enrichProducts(
                products || []
            );


        renderProducts(
            enriched,
            container
        );


    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load your following feed.
            </div>`;

    }

}


/* =========================================================
   FOLLOWERS
========================================================= */

async function loadFollowers() {

    const container =
        document.getElementById(
            "followersList"
        );


    if (!container) return;


    container.innerHTML =
        `<div class="loading-card">
            Loading followers...
        </div>`;


    try {

        const {
            data,
            error
        } = await supabaseClient
            .from("follows")
            .select(`
                follower_id,
                profiles:follower_id (
                    id,
                    full_name,
                    logo_url,
                    created_at
                )
            `)
            .eq(
                "following_id",
                currentUser.id
            );


        if (error) {
            throw error;
        }


        const members =
            (data || [])
                .map(
                    row =>
                        row.profiles
                )
                .filter(Boolean);


        await renderMemberResults(
            members,
            container
        );


    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load followers.
            </div>`;

    }

}


/* =========================================================
   FOLLOWING MEMBERS
========================================================= */

async function loadFollowingMembers() {

    const container =
        document.getElementById(
            "followingMembersList"
        );


    if (!container) return;


    container.innerHTML =
        `<div class="loading-card">
            Loading following...
        </div>`;


    try {

        const {
            data,
            error
        } = await supabaseClient
            .from("follows")
            .select(`
                following_id,
                profiles:following_id (
                    id,
                    full_name,
                    logo_url,
                    created_at
                )
            `)
            .eq(
                "follower_id",
                currentUser.id
            );


        if (error) {
            throw error;
        }


        const members =
            (data || [])
                .map(
                    row =>
                        row.profiles
                )
                .filter(Boolean);


        await renderMemberResults(
            members,
            container
        );


    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load following.
            </div>`;

    }

}


/* =========================================================
   PRODUCT SUBMISSION / SUBSCRIPTION
========================================================= */

async function loadSubscription() {

    if (!currentUser) return;


    try {

        const {
            data,
            error
        } = await supabaseClient
            .from("subscriptions")
            .select(`
                plan,
                status,
                expires_at,
                daily_limit
            `)
            .eq(
                "user_id",
                currentUser.id
            )
            .maybeSingle();


        if (error) {

            /*
             * If no subscription row exists,
             * treat the account as Free.
             */

            console.warn(
                "Subscription lookup:",
                error.message
            );

            currentSubscription = {
                plan: "free",
                status: "active",
                expires_at: null,
                daily_limit: 0
            };

            return;

        }


        if (!data) {

            currentSubscription = {
                plan: "free",
                status: "active",
                expires_at: null,
                daily_limit: 0
            };

            return;

        }


        currentSubscription = {
            plan:
                data.plan || "free",

            status:
                data.status || "active",

            expires_at:
                data.expires_at || null,

            daily_limit:
                Number(
                    data.daily_limit ||
                    plans[
                        data.plan
                    ]?.dailyLimit ||
                    0
                )
        };


        if (
            currentSubscription.expires_at &&
            new Date(
                currentSubscription.expires_at
            ) <= new Date()
        ) {

            currentSubscription = {
                ...currentSubscription,
                status: "expired",
                daily_limit: 0
            };

        }

    } catch (error) {

        console.error(error);

        currentSubscription = {
            plan: "free",
            status: "active",
            expires_at: null,
            daily_limit: 0
        };

    }

}


function subscriptionIsActive() {

    if (
        currentSubscription.plan ===
        "free"
    ) {
        return false;
    }


    if (
        currentSubscription.status !==
        "active"
    ) {
        return false;
    }


    if (
        currentSubscription.expires_at &&
        new Date(
            currentSubscription.expires_at
        ) <= new Date()
    ) {
        return false;
    }


    return (
        Number(
            currentSubscription.daily_limit
        ) > 0
    );

}


/* =========================================================
   DAILY SUBMISSION COUNT
========================================================= */

async function getDailySubmissionCount() {

    if (!currentUser) {
        return 0;
    }


    /*
     * This calls the secure RPC that will be created
     * by supabase.sql.
     *
     * It counts permanent submission events,
     * not current products.
     */

    const {
        data,
        error
    } = await supabaseClient.rpc(
        "get_my_daily_submission_count"
    );


    if (error) {

        console.error(
            "Daily submission RPC error:",
            error
        );

        throw new Error(
            "Unable to check today's product quota."
        );

    }


    return Number(
        data || 0
    );

}


/* =========================================================
   ADD PRODUCT PAGE
========================================================= */

async function updateAddProductPage() {

    await loadSubscription();


    const planName =
        plans[
            currentSubscription.plan
        ]?.name ||
        "Free";


    const planElement =
        document.getElementById(
            "currentPlanName"
        );


    const descriptionElement =
        document.getElementById(
            "currentPlanDescription"
        );


    const quotaElement =
        document.getElementById(
            "dailyQuotaText"
        );


    const requiredMessage =
        document.getElementById(
            "subscriptionRequiredMessage"
        );


    const formContainer =
        document.getElementById(
            "productFormContainer"
        );


    if (planElement) {
        planElement.textContent =
            planName;
    }


    if (descriptionElement) {

        if (
            currentSubscription.plan ===
            "free"
        ) {

            descriptionElement.textContent =
                "Free members cannot submit products.";

        } else {

            descriptionElement.textContent =
                `${
                    currentSubscription.daily_limit
                } products can be submitted per day.`;

        }

    }


    let count = 0;


    try {

        count =
            await getDailySubmissionCount();

    } catch (error) {

        console.error(error);

    }


    const limit =
        Number(
            currentSubscription.daily_limit ||
            0
        );


    if (quotaElement) {

        quotaElement.textContent =
            `${count} / ${limit}`;

    }


    const allowed =
        subscriptionIsActive();


    if (!allowed) {

        requiredMessage?.classList.remove(
            "hidden"
        );

        formContainer?.classList.add(
            "hidden"
        );

        return;

    }


    requiredMessage?.classList.add(
        "hidden"
    );

    formContainer?.classList.remove(
        "hidden"
    );


    if (count >= limit) {

        requiredMessage?.classList.remove(
            "hidden"
        );

        requiredMessage.innerHTML = `
            <strong>
                Daily product limit reached.
            </strong>
            <p>
                You have used ${count} of ${limit}
                submissions for today.
            </p>
        `;

        formContainer?.classList.add(
            "hidden"
        );

    }

}


/* =========================================================
   SUBMIT PRODUCT
========================================================= */

async function submitProduct() {

    if (!currentUser) {

        showToast(
            "Please log in first.",
            "error"
        );

        return;

    }


    const button =
        document.getElementById(
            "submitProductButton"
        );


    const message =
        document.getElementById(
            "productMessage"
        );


    try {

        await loadSubscription();


        if (!subscriptionIsActive()) {

            throw new Error(
                "Your subscription does not allow you to add products."
            );

        }


        const submissionCount =
            await getDailySubmissionCount();


        const limit =
            Number(
                currentSubscription.daily_limit
            );


        if (
            submissionCount >= limit
        ) {

            throw new Error(
                "Daily product limit reached."
            );

        }


        const name =
            document
                .getElementById(
                    "productName"
                )
                .value
                .trim();


        const url =
            document
                .getElementById(
                    "productLink"
                )
                .value
                .trim();


        const category =
            document
                .getElementById(
                    "productCategory"
                )
                .value;


        const description =
            document
                .getElementById(
                    "productDescription"
                )
                .value
                .trim();


        const imageFile =
            document
                .getElementById(
                    "productImage"
                )
                .files[0];


        if (
            !name ||
            !url ||
            !category ||
            !description ||
            !imageFile
        ) {

            throw new Error(
                "Please complete all product fields."
            );

        }


        button.disabled = true;
        button.textContent =
            "Adding product...";


        setMessage(
            "productMessage",
            "Uploading product..."
        );


        const imageUrl =
            await uploadProductImage(
                currentUser.id,
                imageFile
            );


        const {
            data: product,
            error
        } = await supabaseClient
            .from("products")
            .insert({
                owner_id:
                    currentUser.id,

                product_name:
                    name,

                affiliate_url:
                    url,

                image_url:
                    imageUrl,

                description:
                    description,

                category:
                    category
            })
            .select()
            .single();


        if (error) {

            throw error;

        }


        /*
         * The database trigger creates the permanent
         * product_submission_events row.
         *
         * We deliberately do NOT insert that event
         * from JavaScript.
         */


        setMessage(
            "productMessage",
            "Product added successfully."
        );


        document
            .getElementById(
                "addProductForm"
            )
            .reset();


        document
            .getElementById(
                "productImagePreview"
            )
            ?.classList.add(
                "hidden"
            );


        showToast(
            "Product added successfully!",
            "success"
        );


        await updateAddProductPage();

        await loadLatestProducts();


    } catch (error) {

        console.error(error);

        setMessage(
            "productMessage",
            friendlyDatabaseError(error),
            true
        );

    } finally {

        button.disabled = false;
        button.textContent =
            "Add Product";

    }

}


/* =========================================================
   OWN PROFILE
========================================================= */

async function updateProfilePage() {

    if (!currentUser) return;

    await loadCurrentProfile();


    if (!currentProfile) return;


    const image =
        currentProfile.logo_url ||
        "big-save-logo.png";


    document
        .getElementById(
            "profileImage"
        )
        ?.setAttribute(
            "src",
            image
        );


    document
        .getElementById(
            "profileName"
        ).textContent =
            currentProfile.full_name ||
            "Big Save Member";


    document
        .getElementById(
            "profileEmail"
        ).textContent =
            currentUser.email ||
            "";


    document
        .getElementById(
            "settingsProfileImage"
        )
        ?.setAttribute(
            "src",
            image
        );


    document
        .getElementById(
            "accountName"
        ).value =
            currentProfile.full_name ||
            "";


    document
        .getElementById(
            "accountEmail"
        ).value =
            currentUser.email ||
            "";


    document
        .getElementById(
            "accountDob"
        ).value =
            currentProfile.date_of_birth ||
            "";


    const {
        count: followers
    } = await supabaseClient
        .from("follows")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "following_id",
            currentUser.id
        );


    const {
        count: following
    } = await supabaseClient
        .from("follows")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "follower_id",
            currentUser.id
        );


    const {
        count: products
    } = await supabaseClient
        .from("products")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "owner_id",
            currentUser.id
        );


    document
        .getElementById(
            "followerCount"
        ).textContent =
            followers || 0;


    document
        .getElementById(
            "followingCount"
        ).textContent =
            following || 0;


    document
        .getElementById(
            "profileProductCount"
        ).textContent =
            products || 0;


    await loadOwnProfileProducts();

}


/* =========================================================
   OWN PRODUCTS
========================================================= */

async function loadOwnProfileProducts() {

    const container =
        document.getElementById(
            "profileProducts"
        );


    if (!container) return;


    try {

        const products =
            await fetchProducts({
                ownerId:
                    currentUser.id,
                sort:
                    "newest",
                limit:
                    100
            });


        renderProducts(
            products,
            container
        );

    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load your products.
            </div>`;

    }

}


/* =========================================================
   ACCOUNT SETTINGS
========================================================= */

async function saveAccount() {

    if (!currentUser) return;


    const name =
        document
            .getElementById(
                "accountName"
            )
            .value
            .trim();


    const dob =
        document
            .getElementById(
                "accountDob"
            )
            .value;


    const logoFile =
        document
            .getElementById(
                "settingsLogo"
            )
            .files[0];


    try {

        let logoUrl =
            currentProfile?.logo_url ||
            null;


        if (logoFile) {

            logoUrl =
                await uploadProfileImage(
                    currentUser.id,
                    logoFile
                );

        }


        const {
            error
        } = await supabaseClient
            .from("profiles")
            .update({

                full_name:
                    name,

                date_of_birth:
                    dob || null,

                logo_url:
                    logoUrl

            })
            .eq(
                "id",
                currentUser.id
            );


        if (error) {
            throw error;
        }


        await loadCurrentProfile();

        await updateHeader();

        await updateProfilePage();


        setMessage(
            "accountMessage",
            "Account updated successfully."
        );


        showToast(
            "Account updated.",
            "success"
        );


    } catch (error) {

        console.error(error);

        setMessage(
            "accountMessage",
            friendlyDatabaseError(error),
            true
        );

    }

}


/* =========================================================
   CHANGE PASSWORD
========================================================= */

async function changePassword() {

    const password =
        document
            .getElementById(
                "newPassword"
            )
            .value;


    if (!password || password.length < 6) {

        showToast(
            "Password must contain at least 6 characters.",
            "error"
        );

        return;

    }


    try {

        const {
            error
        } = await supabaseClient.auth.updateUser({
            password
        });


        if (error) {
            throw error;
        }


        document
            .getElementById(
                "newPassword"
            )
            .value = "";


        showToast(
            "Password changed successfully.",
            "success"
        );


    } catch (error) {

        console.error(error);

        showToast(
            friendlyAuthError(error),
            "error"
        );

    }

}


/* =========================================================
   SETTINGS NAVIGATION
========================================================= */

function showSettings(
    section
) {

    const sections = [
        "account",
        "affiliate",
        "notifications",
        "addedProducts",
        "privacy",
        "appearance",
        "support",
        "legal"
    ];


    sections.forEach(name => {

        document
            .getElementById(
                `settings${capitalize(name)}`
            )
            ?.classList.add(
                "hidden"
            );

    });


    document
        .getElementById(
            `settings${capitalize(section)}`
        )
        ?.classList.remove(
            "hidden"
        );


    document
        .querySelectorAll(
            ".settings-tab"
        )
        .forEach(button => {

            button.classList.toggle(
                "active",
                button.dataset.settings ===
                    section
            );

        });


    if (
        section ===
        "affiliate"
    ) {
        loadAffiliateSettings();
    }


    if (
        section ===
        "notifications"
    ) {
        loadNotificationSettings();
    }


    if (
        section ===
        "addedProducts"
    ) {
        loadAddedProducts();
    }

}


/* =========================================================
   AFFILIATE SETTINGS
========================================================= */

async function loadAffiliateSettings() {

    const {
        data,
        error
    } = await supabaseClient
        .from("affiliate_profiles")
        .select(`
            network,
            affiliate_id,
            default_store
        `)
        .eq(
            "user_id",
            currentUser.id
        )
        .maybeSingle();


    if (error) {

        console.error(error);

        return;

    }


    if (!data) return;


    document
        .getElementById(
            "affiliateNetwork"
        ).value =
            data.network || "";


    document
        .getElementById(
            "affiliateId"
        ).value =
            data.affiliate_id || "";


    document
        .getElementById(
            "defaultStore"
        ).value =
            data.default_store ||
            "Amazon";

}


async function saveAffiliate() {

    try {

        const network =
            document
                .getElementById(
                    "affiliateNetwork"
                )
                .value;


        const affiliateId =
            document
                .getElementById(
                    "affiliateId"
                )
                .value
                .trim();


        const defaultStore =
            document
                .getElementById(
                    "defaultStore"
                )
                .value;


        const {
            error
        } = await supabaseClient
            .from("affiliate_profiles")
            .upsert({
                user_id:
                    currentUser.id,

                network:
                    network || null,

                affiliate_id:
                    affiliateId || null,

                default_store:
                    defaultStore || null,

                updated_at:
                    new Date().toISOString()

            });


        if (error) {
            throw error;
        }


        setMessage(
            "affiliateMessage",
            "Affiliate settings saved."
        );


        showToast(
            "Affiliate settings saved.",
            "success"
        );


    } catch (error) {

        console.error(error);

        setMessage(
            "affiliateMessage",
            friendlyDatabaseError(error),
            true
        );

    }

}


/* =========================================================
   NOTIFICATION PREFERENCES
========================================================= */

async function loadNotificationSettings() {

    const {
        data,
        error
    } = await supabaseClient
        .from("notification_preferences")
        .select(`
            deal_notifications,
            product_notifications,
            affiliate_notifications,
            email_notifications
        `)
        .eq(
            "user_id",
            currentUser.id
        )
        .maybeSingle();


    if (error) {

        console.error(error);

        return;

    }


    if (!data) return;


    document
        .getElementById(
            "notifyDeals"
        ).checked =
            !!data.deal_notifications;


    document
        .getElementById(
            "notifyProducts"
        ).checked =
            !!data.product_notifications;


    document
        .getElementById(
            "notifyAffiliate"
        ).checked =
            !!data.affiliate_notifications;


    document
        .getElementById(
            "notifyEmail"
        ).checked =
            !!data.email_notifications;

}


async function saveNotifications() {

    try {

        const values = {

            deal_notifications:
                document
                    .getElementById(
                        "notifyDeals"
                    )
                    .checked,

            product_notifications:
                document
                    .getElementById(
                        "notifyProducts"
                    )
                    .checked,

            affiliate_notifications:
                document
                    .getElementById(
                        "notifyAffiliate"
                    )
                    .checked,

            email_notifications:
                document
                    .getElementById(
                        "notifyEmail"
                    )
                    .checked,

            updated_at:
                new Date().toISOString()

        };


        const {
            error
        } = await supabaseClient
            .from("notification_preferences")
            .upsert({
                user_id:
                    currentUser.id,
                ...values
            });


        if (error) {
            throw error;
        }


        setMessage(
            "notificationMessage",
            "Notification settings saved."
        );


        showToast(
            "Notification settings saved.",
            "success"
        );


    } catch (error) {

        console.error(error);

        setMessage(
            "notificationMessage",
            friendlyDatabaseError(error),
            true
        );

    }

}


/* =========================================================
   ADDED PRODUCTS
========================================================= */

async function loadAddedProducts() {

    const container =
        document.getElementById(
            "addedProductsList"
        );


    if (!container) return;


    container.innerHTML =
        `<div class="loading-card">
            Loading your products...
        </div>`;


    try {

        const products =
            await fetchProducts({
                ownerId:
                    currentUser.id,
                sort:
                    "newest",
                limit:
                    100
            });


        if (!products.length) {

            container.innerHTML = "";

            document
                .getElementById(
                    "addedProductsEmpty"
                )
                ?.classList.remove(
                    "hidden"
                );

            return;

        }


        document
            .getElementById(
                "addedProductsEmpty"
            )
            ?.classList.add(
                "hidden"
            );


        container.innerHTML = "";


        products.forEach(
            product => {

                const item =
                    document.createElement(
                        "div"
                    );

                item.className =
                    "settings-product-item";


                item.innerHTML = `

                    <img
                        src="${escapeAttribute(
                            product.image_url ||
                            "big-save-logo.png"
                        )}"
                        alt=""
                    >

                    <div class="settings-product-info">

                        <h3>
                            ${escapeHtml(
                                product.product_name
                            )}
                        </h3>

                        <p>
                            ${escapeHtml(
                                product.category
                            )}
                            ·
                            ${formatDate(
                                product.created_at
                            )}
                            ·
                            👁 ${product.viewCount}
                            ·
                            ♡ ${product.likeCount}
                        </p>

                    </div>

                    <div class="settings-product-actions">

                        <button
                            type="button"
                            class="secondary-btn"
                        >
                            Edit
                        </button>

                        <button
                            type="button"
                            class="danger-btn"
                        >
                            Remove
                        </button>

                    </div>
                `;


                const buttons =
                    item.querySelectorAll(
                        "button"
                    );


                buttons[0].addEventListener(
                    "click",
                    () =>
                        openEditProductModal(
                            product
                        )
                );


                buttons[1].addEventListener(
                    "click",
                    () =>
                        confirmRemoveProduct(
                            product
                        )
                );


                container.appendChild(
                    item
                );

            }
        );


    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load your products.
            </div>`;

    }

}


/* =========================================================
   EDIT PRODUCT
========================================================= */

function openEditProductModal(
    product
) {

    document
        .getElementById(
            "editProductId"
        ).value =
            product.id;


    document
        .getElementById(
            "editProductName"
        ).value =
            product.product_name;


    document
        .getElementById(
            "editProductCategory"
        ).value =
            product.category;


    document
        .getElementById(
            "editProductLink"
        ).value =
            product.affiliate_url;


    document
        .getElementById(
            "editProductDescription"
        ).value =
            product.description || "";


    document
        .getElementById(
            "editProductModal"
        )
        ?.classList.remove(
            "hidden"
        );

}


function closeEditProductModal() {

    document
        .getElementById(
            "editProductModal"
        )
        ?.classList.add(
            "hidden"
        );

}


async function saveEditedProduct() {

    const productId =
        document
            .getElementById(
                "editProductId"
            )
            .value;


    try {

        const name =
            document
                .getElementById(
                    "editProductName"
                )
                .value
                .trim();


        const category =
            document
                .getElementById(
                    "editProductCategory"
                )
                .value;


        const url =
            document
                .getElementById(
                    "editProductLink"
                )
                .value
                .trim();


        const description =
            document
                .getElementById(
                    "editProductDescription"
                )
                .value
                .trim();


        const imageFile =
            document
                .getElementById(
                    "editProductImage"
                )
                .files[0];


        const update = {

            product_name:
                name,

            category:
                category,

            affiliate_url:
                url,

            description:
                description

        };


        if (imageFile) {

            update.image_url =
                await uploadProductImage(
                    currentUser.id,
                    imageFile
                );

        }


        const {
            error
        } = await supabaseClient
            .from("products")
            .update(update)
            .eq(
                "id",
                productId
            )
            .eq(
                "owner_id",
                currentUser.id
            );


        if (error) {
            throw error;
        }


        closeEditProductModal();


        showToast(
            "Product updated successfully.",
            "success"
        );


        await loadAddedProducts();

        await loadOwnProfileProducts();


    } catch (error) {

        console.error(error);

        setMessage(
            "editProductMessage",
            friendlyDatabaseError(error),
            true
        );

    }

}


/* =========================================================
   DELETE PRODUCT
========================================================= */

function confirmRemoveProduct(
    product
) {

    openConfirmModal(
        "Remove Product",
        `Remove "${product.product_name}"? This action cannot be undone. Your daily submission quota will NOT be restored.`,
        async () => {

            await removeProduct(
                product.id
            );

        }
    );

}


async function removeProduct(
    productId
) {

    try {

        const {
            error
        } = await supabaseClient
            .from("products")
            .delete()
            .eq(
                "id",
                productId
            )
            .eq(
                "owner_id",
                currentUser.id
            );


        if (error) {
            throw error;
        }


        showToast(
            "Product removed successfully.",
            "success"
        );


        await loadAddedProducts();

        await updateAddProductPage();

        await loadOwnProfileProducts();


    } catch (error) {

        console.error(error);

        showToast(
            "Unable to remove product.",
            "error"
        );

    }

}


/* =========================================================
   NOTIFICATIONS
========================================================= */

async function loadNotifications() {

    const container =
        document.getElementById(
            "notificationsList"
        );


    if (!container) return;


    container.innerHTML =
        `<div class="loading-card">
            Loading notifications...
        </div>`;


    try {

        const {
            data,
            error
        } = await supabaseClient
            .from("notifications")
            .select(`
                id,
                recipient_id,
                actor_id,
                product_id,
                type,
                message,
                is_read,
                created_at,
                actor:actor_id (
                    id,
                    full_name,
                    logo_url
                )
            `)
            .eq(
                "recipient_id",
                currentUser.id
            )
            .order(
                "created_at",
                {
                    ascending: false
                }
            )
            .limit(100);


        if (error) {
            throw error;
        }


        if (!data?.length) {

            container.innerHTML =
                `<div class="loading-card">
                    No notifications yet.
                </div>`;

            return;

        }


        container.innerHTML = "";


        data.forEach(
            notification => {

                const item =
                    document.createElement(
                        "article"
                    );

                item.className =
                    "notification-item";


                if (
                    !notification.is_read
                ) {

                    item.classList.add(
                        "unread"
                    );

                }


                item.innerHTML = `

                    <div class="notification-icon">
                        🔔
                    </div>

                    <div class="notification-content">

                        <p class="notification-message">
                            ${escapeHtml(
                                notification.message ||
                                "New notification"
                            )}
                        </p>

                        <span class="notification-date">
                            ${formatDateTime(
                                notification.created_at
                            )}
                        </span>

                    </div>

                    ${
                        notification.is_read
                            ? ""
                            : `
                                <button
                                    type="button"
                                    class="notification-read-btn"
                                >
                                    Mark read
                                </button>
                            `
                    }

                `;


                item.addEventListener(
                    "click",
                    async event => {

                        if (
                            event.target.closest(
                                ".notification-read-btn"
                            )
                        ) {
                            return;
                        }


                        await markNotificationRead(
                            notification.id
                        );


                        if (
                            notification.product_id
                        ) {

                            await openProductDetail(
                                notification.product_id
                            );

                        } else if (
                            notification.actor_id
                        ) {

                            await openPublicProfile(
                                notification.actor_id
                            );

                        }

                    }
                );


                const readButton =
                    item.querySelector(
                        ".notification-read-btn"
                    );


                readButton?.addEventListener(
                    "click",
                    async event => {

                        event.stopPropagation();

                        await markNotificationRead(
                            notification.id
                        );

                        await loadNotifications();

                    }
                );


                container.appendChild(
                    item
                );

            }
        );


        await loadNotificationBadge();


    } catch (error) {

        console.error(error);

        container.innerHTML =
            `<div class="loading-card">
                Unable to load notifications.
            </div>`;

    }

}


/* =========================================================
   NOTIFICATION BADGE
========================================================= */

async function loadNotificationBadge() {

    if (!currentUser) return;


    const {
        count,
        error
    } = await supabaseClient
        .from("notifications")
        .select(
            "id",
            {
                count: "exact",
                head: true
            }
        )
        .eq(
            "recipient_id",
            currentUser.id
        )
        .eq(
            "is_read",
            false
        );


    if (error) {

        console.error(error);

        return;

    }


    const badge =
        document.getElementById(
            "notificationBadge"
        );


    if (!badge) return;


    if (!count) {

        badge.classList.add(
            "hidden"
        );

        badge.textContent =
            "0";

        return;

    }


    badge.classList.remove(
        "hidden"
    );


    badge.textContent =
        count > 99
            ? "99+"
            : String(count);

}


async function markNotificationRead(
    notificationId
) {

    const {
        error
    } = await supabaseClient
        .from("notifications")
        .update({
            is_read: true
        })
        .eq(
            "id",
            notificationId
        )
        .eq(
            "recipient_id",
            currentUser.id
        );


    if (error) {

        console.error(error);

        return;

    }


    await loadNotificationBadge();

}


async function markAllNotificationsRead() {

    try {

        const {
            error
        } = await supabaseClient
            .from("notifications")
            .update({
                is_read: true
            })
            .eq(
                "recipient_id",
                currentUser.id
            )
            .eq(
                "is_read",
                false
            );


        if (error) {
            throw error;
        }


        await loadNotifications();

        await loadNotificationBadge();


        showToast(
            "All notifications marked as read.",
            "success"
        );


    } catch (error) {

        console.error(error);

        showToast(
            "Unable to update notifications.",
            "error"
        );

    }

}


/* =========================================================
   APPEARANCE / DARK MODE
========================================================= */

function applySavedTheme() {

    const saved =
        localStorage.getItem(
            "bigSaveTheme"
        ) || "light";


    document.body.classList.toggle(
        "dark-mode",
        saved === "dark"
    );


    const selector =
        document.getElementById(
            "themeSelect"
        );


    if (selector) {
        selector.value = saved;
    }

}


function changeTheme() {

    const theme =
        document
            .getElementById(
                "themeSelect"
            )
            .value;


    localStorage.setItem(
        "bigSaveTheme",
        theme
    );


    document.body.classList.toggle(
        "dark-mode",
        theme === "dark"
    );


    showToast(
        `${capitalize(theme)} mode enabled.`,
        "success"
    );

}


/* =========================================================
   CATEGORY
========================================================= */

function openCategory(
    category
) {

    document
        .getElementById(
            "categoryFilter"
        ).value =
            category;


    showPage(
        "discover"
    );

}


/* =========================================================
   IMAGE PREVIEW
========================================================= */

function setupImagePreview() {

    const input =
        document.getElementById(
            "productImage"
        );

    const preview =
        document.getElementById(
            "productImagePreview"
        );


    if (!input || !preview) {
        return;
    }


    input.addEventListener(
        "change",
        () => {

            const file =
                input.files[0];


            if (!file) {

                preview.classList.add(
                    "hidden"
                );

                preview.innerHTML =
                    "";

                return;

            }


            const reader =
                new FileReader();


            reader.onload =
                event => {

                    preview.innerHTML =
                        `
                            <img
                                src="${event.target.result}"
                                alt="Product preview"
                            >
                        `;

                    preview.classList.remove(
                        "hidden"
                    );

                };


            reader.readAsDataURL(
                file
            );

        }
    );

}


/* =========================================================
   SUPPORT
========================================================= */

function sendSupportEmail() {

    const subject =
        document
            .getElementById(
                "supportSubject"
            )
            .value
            .trim();


    const message =
        document
            .getElementById(
                "supportMessage"
            )
            .value
            .trim();


    if (!subject || !message) {

        showToast(
            "Please enter a subject and message.",
            "error"
        );

        return;

    }


    const email =
        "bigsavesupport@gmail.com";


    const mailto =
        `mailto:${email}` +
        `?subject=${encodeURIComponent(subject)}` +
        `&body=${encodeURIComponent(message)}`;


    window.location.href =
        mailto;

}


/* =========================================================
   CONFIRM MODAL
========================================================= */

function openConfirmModal(
    title,
    message,
    callback
) {

    document
        .getElementById(
            "confirmTitle"
        ).textContent =
            title;


    document
        .getElementById(
            "confirmMessage"
        ).textContent =
            message;


    confirmCallback =
        callback;


    document
        .getElementById(
            "confirmModal"
        )
        ?.classList.remove(
            "hidden"
        );


    const button =
        document.getElementById(
            "confirmActionButton"
        );


    button.onclick =
        async () => {

            const callbackToRun =
                confirmCallback;

            closeConfirmModal();

            if (callbackToRun) {
                await callbackToRun();
            }

        };

}


function closeConfirmModal() {

    document
        .getElementById(
            "confirmModal"
        )
        ?.classList.add(
            "hidden"
        );

    confirmCallback =
        null;

}


/* =========================================================
   TOAST
========================================================= */

function showToast(
    message,
    type = "success"
) {

    const container =
        document.getElementById(
            "toastContainer"
        );


    if (!container) return;


    const toast =
        document.createElement(
            "div"
        );


    toast.className =
        `toast ${type}`;


    toast.textContent =
        message;


    container.appendChild(
        toast
    );


    setTimeout(
        () => {

            toast.remove();

        },
        3500
    );

}


/* =========================================================
   MESSAGES
========================================================= */

function setMessage(
    elementId,
    message,
    isError = false
) {

    const element =
        document.getElementById(
            elementId
        );


    if (!element) return;


    element.textContent =
        message;


    element.classList.toggle(
        "error",
        isError
    );

}


/* =========================================================
   ERROR HELPERS
========================================================= */

function friendlyAuthError(
    error
) {

    const message =
        error?.message ||
        "";


    const lower =
        message.toLowerCase();


    if (
        lower.includes(
            "invalid login credentials"
        )
    ) {
        return "Incorrect email or password.";
    }


    if (
        lower.includes(
            "email not confirmed"
        )
    ) {
        return "Email confirmation is enabled in Supabase. Turn Confirm email off for V1.";
    }


    if (
        lower.includes(
            "user already registered"
        )
    ) {
        return "An account with this email already exists.";
    }


    if (
        lower.includes(
            "password"
        ) &&
        lower.includes(
            "6"
        )
    ) {
        return "Password must contain at least 6 characters.";
    }


    return message ||
        "Authentication failed. Please try again.";

}


function friendlyDatabaseError(
    error
) {

    const message =
        error?.message ||
        "";


    if (
        message.includes(
            "row-level security"
        )
    ) {

        return "This action is blocked by database security. Check the Supabase RLS setup.";

    }


    if (
        message.includes(
            "duplicate"
        )
    ) {

        return "This record already exists.";

    }


    return message ||
        "Something went wrong. Please try again.";

}


/* =========================================================
   HTML SAFETY
========================================================= */

function escapeHtml(
    value
) {

    return String(
        value ?? ""
    )
        .replaceAll(
            "&",
            "&amp;"
        )
        .replaceAll(
            "<",
            "&lt;"
        )
        .replaceAll(
            ">",
            "&gt;"
        )
        .replaceAll(
            '"',
            "&quot;"
        )
        .replaceAll(
            "'",
            "&#039;"
        );

}


function escapeAttribute(
    value
) {

    return escapeHtml(
        value
    );

}


/* =========================================================
   DATE HELPERS
========================================================= */

function formatDate(
    value
) {

    if (!value) {
        return "Unknown date";
    }


    const date =
        new Date(value);


    return date.toLocaleDateString(
        "en-IN",
        {
            day: "numeric",
            month: "short",
            year: "numeric"
        }
    );

}


function formatDateTime(
    value
) {

    if (!value) {
        return "Unknown time";
    }


    const date =
        new Date(value);


    return date.toLocaleString(
        "en-IN",
        {
            day: "numeric",
            month: "short",
            year: "numeric",
            hour: "numeric",
            minute: "2-digit"
        }
    );

}


/* =========================================================
   GENERAL HELPERS
========================================================= */

function capitalize(
    value
) {

    if (!value) return "";

    return (
        value.charAt(0).toUpperCase() +
        value.slice(1)
    );

}


/* =========================================================
   DEBUG HELPER
========================================================= */

window.BigSave = {

    getCurrentUser() {
        return currentUser;
    },

    getCurrentProfile() {
        return currentProfile;
    },

    getSubscription() {
        return currentSubscription;
    },

    showPage,

    loadDiscoverProducts,

    loadNotifications

};


/* =========================================================
   END OF BIG SAVE V1 APP
========================================================= */